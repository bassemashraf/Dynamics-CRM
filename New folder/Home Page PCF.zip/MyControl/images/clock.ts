export const  clock = `<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="32" height="32" rx="12" fill="#ECE7DA"/>
<path d="M16 8V16H22M28 16C28 22.6274 22.6274 28 16 28C9.37258 28 4 22.6274 4 16C4 9.37258 9.37258 4 16 4C22.6274 4 28 9.37258 28 16Z" stroke="#0C0D0C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`; 