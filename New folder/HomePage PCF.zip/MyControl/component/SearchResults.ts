/* eslint-disable */
import * as React from 'react';

interface ISearchResult {
    accountid: string;
    name: string;
}

interface ISearchResultsProps {
    results: ISearchResult[];
    onRecordClick: (accountId: string) => void;
    onClose: () => void;
}

export const SearchResults = (props: ISearchResultsProps) => {
    const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>): void => {
        e.currentTarget.style.backgroundColor = '#f3f2f1';
    };

    const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>): void => {
        e.currentTarget.style.backgroundColor = 'white';
    };

    const isLandscape = (): boolean => {
        return window.innerWidth > window.innerHeight;
    };

    const { results, onRecordClick, onClose } = props;
    const landscape = isLandscape();

    return React.createElement(
        'div',
        {
            style: {
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: 'rgba(0, 0, 0, 0.4)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                zIndex: 1000,
            }
        },
        React.createElement(
            'div',
            {
                style: {
                    backgroundColor: 'white',
                    borderRadius: landscape ? '2px' : '0',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                    width: landscape ? '90%' : '100%',
                    maxWidth: landscape ? '800px' : '100%',
                    height: landscape ? 'auto' : '100%',
                    maxHeight: landscape ? '80vh' : '100%',
                    display: 'flex',
                    flexDirection: 'column',
                }
            },
            // Header
            React.createElement(
                'div',
                {
                    style: {
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '16px 20px',
                        borderBottom: '1px solid #edebe9',
                    }
                },
                React.createElement(
                    'h2',
                    {
                        style: {
                            margin: 0,
                            fontSize: '20px',
                            fontWeight: 600,
                            color: '#323130',
                        }
                    },
                    `Search Results (${results.length})`
                ),
                React.createElement(
                    'button',
                    {
                        style: {
                            background: 'none',
                            border: 'none',
                            fontSize: '28px',
                            color: '#605e5c',
                            cursor: 'pointer',
                            padding: '0 8px',
                            lineHeight: 1,
                        },
                        onClick: onClose
                    },
                    '×'
                )
            ),
            // Content wrapper
            React.createElement(
                'div',
                {
                    style: {
                        flex: 1,
                        overflow: 'hidden',
                        display: 'flex',
                        flexDirection: 'column',
                    }
                },
                // Column Headers
                React.createElement(
                    'div',
                    {
                        style: {
                            display: 'flex',
                            padding: '12px 20px',
                            backgroundColor: '#faf9f8',
                            borderBottom: '1px solid #edebe9',
                            fontWeight: 600,
                            fontSize: '14px',
                            color: '#323130',
                        }
                    },
                    React.createElement(
                        'div',
                        { style: { flex: 1, minWidth: 0 } },
                        'Account Name'
                    ),
                    React.createElement(
                        'div',
                        { style: { width: '280px', flexShrink: 0 } },
                        'Account ID'
                    )
                ),
                // Scrollable Results
                React.createElement(
                    'div',
                    {
                        style: {
                            flex: 1,
                            overflowY: 'auto',
                        }
                    },
                    results.map((record: ISearchResult) =>
                        React.createElement(
                            'div',
                            {
                                key: record.accountid,
                                style: {
                                    display: 'flex',
                                    padding: '12px 20px',
                                    borderBottom: '1px solid #edebe9',
                                    cursor: 'pointer',
                                    transition: 'background-color 0.1s',
                                    backgroundColor: 'white'
                                },
                                onClick: () => onRecordClick(record.accountid),
                                onMouseEnter: handleMouseEnter,
                                onMouseLeave: handleMouseLeave
                            },
                            React.createElement(
                                'div',
                                {
                                    style: {
                                        flex: 1,
                                        minWidth: 0,
                                        fontSize: '14px',
                                        color: '#0078d4',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }
                                },
                                record.name
                            ),
                            React.createElement(
                                'div',
                                {
                                    style: {
                                        width: '280px',
                                        flexShrink: 0,
                                        fontSize: '14px',
                                        color: '#605e5c',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }
                                },
                                record.accountid
                            )
                        )
                    )
                )
            )
        )
    );
};