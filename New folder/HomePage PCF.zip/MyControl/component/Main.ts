/* eslint-disable */
import * as React from "react";
import { IInputs } from "../generated/ManifestTypes";
import { SearchResults } from "./SearchResults";
import { logoBase64 } from "../images/logo64";
import { startSvgContent } from "../images/start";
import { magnify } from "../images/magnify";
import { calender } from "../images/calender";
import { clock } from "../images/clock";
import { check } from "../images/check";
import {filters} from "../images/filters";
// Define the interface for the component's internal state.
interface State {
    searchText: string;
    pendingIns: number | null;
    completedIns: number | null;
    userName: string;
    message?: string;
    isLoading: boolean;
    showResults: boolean;
    searchResults: any[];
}

// Define the interface for the component's properties (props) coming from the Power Apps Component Framework (PCF).
interface IProps {
    context: ComponentFramework.Context<IInputs>;
}

// --- Custom Styles Derived from main.css & Bootstrap ---
const STYLES = {
    textBrown: { color: "#A89360" },
    textGreen: { color: "#29A283" },
    bgBrownLight: { backgroundColor: "#ECE7DA" },
    bgGreenLight: { backgroundColor: "#CCEEE9" },
    welcomeBanner: {
        fontSize: "18px",
        backgroundColor: "#CFE0E5",
        paddingTop: 8,
        paddingBottom: 8,
        textAlign: "center" as const,
        marginBottom: 0
    },
    actions: {
        backgroundColor: "#F3F3F3",
        padding: 12,
        paddingTop: 16,
        paddingBottom: 16,
        display: "flex",
        flexDirection: "column" as const,
        gap: 12,
    },
    icon: {
        width: 56,
        height: 56,
        minWidth: 56,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 4,
    },
    btnBlueDark: {
        backgroundColor: "#113f61",
        border: "none",
    },
    btnRedDark: {
        backgroundColor: "#8A1538",
        border: "none",
    },
    flexGrow1: { flexGrow: 1 },
    dFlex: { display: "flex" },
    alignItemsCenter: { alignItems: "center" },
    justifyContentBetween: { justifyContent: "space-between" },
    justifyContentCenter: { justifyContent: "center" },
    gap3: { gap: 12 },
    p3: { padding: 12 },
    py4: { paddingTop: 16, paddingBottom: 16 },
    mb3: { marginBottom: 12 },
    h1: { fontSize: 32, fontWeight: "bold" as const, margin: 0 },
    h6: { fontSize: 16, margin: 0 },
    rounded4: { borderRadius: 16 },
    rounded3: { borderRadius: 4 },
    border: { border: "1px solid #ccc" },
    textWhite: { color: "white" },
    textCenter: { textAlign: "center" as const }
};

export const Main = (props: IProps) => {
    const [state, setState] = React.useState<State>({
        searchText: "",
        pendingIns: null,
        completedIns: null,
        userName: "Loading...",
        message: undefined,
        isLoading: false,
        searchResults: [],
        showResults: false,
    });
    const startDataUri = "data:image/svg+xml;base64," + btoa(startSvgContent);
    const magnifyDataUri = "data:image/svg+xml;base64," + btoa(magnify);
    const calenderDataUri = "data:image/svg+xml;base64," + btoa(calender);
    const checkDataUri = "data:image/svg+xml;base64," + btoa(check);
    const clockDataUri = "data:image/svg+xml;base64," + btoa(clock);
    const filtersDataUri = "data:image/svg+xml;base64," + btoa(filters);



    const isOffline = (): boolean => {
        const ctx: any = props.context;
        return ctx.mode?.isInOfflineMode === true;
    };

    // Uncomment to force offline mode for testing
    // const isOffline = (): boolean => {
    //     return true;
    // };

    const loadUserData = React.useCallback(async (): Promise<void> => {
        const ctx: any = props.context;
        try {
            if (!ctx) return;
            const userSettings = ctx.userSettings;
            const userId = (userSettings.userId ?? "").replace("{", "").replace("}", "");
            let res: any = null;
            if (isOffline()) {
                const results = await ctx.utils.executeOffline(
                    "systemuser",
                    `?$filter=systemuserid eq ${userId}&$select=duc_myclosedinspections,duc_mypendinginspections,duc_usernamearabic`
                );
                res = results?.entities?.[0] ?? null;
            } else {
                res = await ctx.webAPI.retrieveRecord(
                    "systemuser",
                    userId,
                    "?$select=duc_myclosedinspections,duc_mypendinginspections,duc_usernamearabic"
                );
            }
            if (res) {
                const pending = res.duc_mypendinginspections ?? 0;
                const completed = res.duc_myclosedinspections ?? 0;
                const username = res.duc_usernamearabic ?? userSettings?.userName ?? "Inspector";
                setState(prev => ({ ...prev, pendingIns: pending, completedIns: completed, userName: username }));
                localStorage.setItem(
                    "MOCI_userCounts",
                    JSON.stringify({ pendingIns: pending, completedIns: completed, userName: username })
                );
            }
        } catch (e) {
            console.warn("User data load failed, using cache.", e);
            restoreCache();
        }
    }, [props.context]);

    const restoreCache = (): void => {
        const cached = localStorage.getItem("MOCI_userCounts");
        if (cached) {
            try {
                const obj = JSON.parse(cached);
                setState(prev => ({
                    ...prev,
                    pendingIns: obj.pendingIns,
                    completedIns: obj.completedIns,
                    userName: obj.userName ?? "Inspector"
                }));
            } catch {
                // ignore corrupted cache
            }
        }
    };

    React.useEffect(() => {
        void loadUserData();
        restoreCache();
    }, [loadUserData]);

    const onKeyUp = (e: React.KeyboardEvent<HTMLInputElement>): void => {
        if (e.key === "Enter") void onSearchClick();
    };

    const onSearchClick = async (): Promise<void> => {
        const text = state.searchText.trim();
        if (!text) {
            setState(prev => ({ ...prev, message: "Please enter a search value" }));
            return;
        }
        setState(prev => ({ ...prev, isLoading: true, message: undefined }));
        const ctx: any = props.context;
        const searchKey = `MOCI_lastSearch_${text.toLowerCase()}`;

        try {
            let results: any = null;

            if (isOffline()) {
                results = await ctx.utils.executeOffline(
                    "account",
                    `?$top=100`
                );
                setState(prev => ({
                    ...prev,
                    message: `come form offline mode, total records fetched: `
                }));
                if (text) {
                    const lowerText = text.toLowerCase();
                    results.entities = results.entities.filter((entity: any) => {
                        const entityName = entity.name as string | undefined;
                        return entityName?.toLowerCase().startsWith(lowerText) ?? false;
                    });
                }
            } else {
                const escapedText = text.replace(/'/g, "''");
                setState(prev => ({
                    ...prev,
                    message: `come form online mode, total records fetched: `
                }));
                results = await ctx.webAPI.retrieveMultipleRecords(
                    "account",
                    `?$top=10`
                );
                if (text) {
                    const lowerText = text.toLowerCase();
                    results.entities = results.entities.filter((entity: any) => {
                        const entityName = entity.name as string | undefined;
                        return entityName?.toLowerCase().startsWith(lowerText) ?? false;
                    });
                }
            }
            // $filter=startswith(name,'${escapedText}')&

            const entities = results?.entities ?? [];

            if (entities.length === 0) {
                setState(prev => ({ ...prev, message: "No results found" }));
            } else if (entities.length === 1 && !isOffline()) {
                void ctx.navigation.navigateTo({
                    pageType: "entityrecord",
                    entityName: "account",
                    entityId: entities[0].accountid
                });
            } else {
                setState(prev => ({
                    ...prev,
                    showResults: true,
                    searchResults: entities,
                    message: undefined
                }));
            }

            localStorage.setItem(searchKey, JSON.stringify(results));
        } catch (err: any) {
            console.error(err);
            const cached = localStorage.getItem(searchKey);
            if (cached) {
                const parsed = JSON.parse(cached);
                setState(prev => ({
                    ...prev,
                    showResults: true,
                    searchResults: parsed.entities,
                    message: "Search failed, showing cached results (offline)."
                }));
            } else {
                setState(prev => ({
                    ...prev,
                    message: `${err?.message ?? err}  Search failed v.3 No cached data available offline.`
                }));
            }
        } finally {
            setState(prev => ({ ...prev, isLoading: false }));
        }
    };

    const onRecordClick = (accountId: string): void => {
        const ctx: any = props.context;
        setState(prev => ({ ...prev, showResults: false }));

        void ctx.navigation.navigateTo({
            pageType: "entityrecord",
            entityName: "account",
            entityId: accountId
        });
    };

    const onCloseResults = (): void => {
        setState(prev => ({ ...prev, showResults: false }));
    };

    const openScheduled = (): void => {
        const ctx: any = props.context;
        if (isOffline()) {
            setState(prev => ({ ...prev, message: "Cannot open Scheduled Inspections: Navigation blocked in offline mode for safety." }));
            return;
        }
        void ctx.navigation.navigateTo({
            pageType: "entitylist",
            entityName: "bookableresourcebooking",
            viewId: "4073baca-cc5f-e611-8109-000d3a146973"
        });
    };

    const closedWorkorders = (): void => {
        const ctx: any = props.context;
        if (isOffline()) {
            setState(prev => ({ ...prev, message: "Cannot open Closed Inspections: Navigation blocked in offline mode for safety." }));
            return;
        }
        void ctx.navigation.navigateTo({
            pageType: "entitylist",
            entityName: "msdyn_workorder",
            viewId: "1606c246-dc8a-eb11-b1ac-000d3ab40477"
        });
    };

    const startInspection = (): void => {
        const ctx: any = props.context;
        if (isOffline()) {
            setState(prev => ({ ...prev, message: "Cannot start inspection (open quick create form) in offline mode" }));
            return;
        }
        void ctx.navigation.openForm({ entityName: "msdyn_workorder", useQuickCreateForm: true }, {});
    };

    const { searchText, pendingIns, completedIns, userName, message, isLoading, showResults, searchResults } = state;
    const isActionDisabled = isLoading;

    const getButtonStyle = (baseStyle: React.CSSProperties) => ({
        ...baseStyle,
        opacity: isActionDisabled ? 0.6 : 1,
        cursor: isActionDisabled ? 'not-allowed' : 'pointer',
    });

    return React.createElement(
        React.Fragment,
        null,
        React.createElement(
            "div",
            { style: { ...STYLES.dFlex, flexDirection: 'column', height: '100%' } },
            // Header
            React.createElement(
                "header",
                { style: { ...STYLES.dFlex, ...STYLES.alignItemsCenter, ...STYLES.justifyContentCenter, paddingTop: 16, paddingBottom: 16 } },
                React.createElement(
                    "a",
                    { href: "#", style: { display: 'block' } },
                    React.createElement("img", { alt: "", src: logoBase64 })
                )
            ),
            // Welcome Banner
            React.createElement(
                "div",
                { style: STYLES.welcomeBanner },
                `Welcome Back, ${userName}`
            ),
            // Main Content
            React.createElement(
                "div",
                { style: { ...STYLES.flexGrow1, ...STYLES.p3 } },
                // Search Bar
                React.createElement(
                    "div",
                    { style: { ...STYLES.dFlex, ...STYLES.gap3, ...STYLES.mb3, opacity: isLoading ? 0.6 : 1 } },
                    React.createElement(
                        "div",
                        { style: { ...STYLES.flexGrow1, ...STYLES.dFlex, ...STYLES.border, ...STYLES.rounded3, ...STYLES.alignItemsCenter, ...STYLES.gap3, ...STYLES.p3 } },
                        React.createElement("img", {
                            src: magnifyDataUri,
                        }),
                        React.createElement(
                            "div",
                            { style: STYLES.flexGrow1 },
                            React.createElement("input", {
                                type: "text",
                                placeholder: "Search Account Name",
                                value: searchText,
                                onChange: (e) => setState(prev => ({ ...prev, searchText: e.target.value })),
                                onKeyUp: onKeyUp,
                                disabled: isLoading,
                                style: { border: 'none', width: '100%', outline: 'none' }
                            })
                        )
                    ),
                    React.createElement("image",
                        {
                            src: filtersDataUri,
                            style: {  border: 'none', padding: '12px', borderRadius: 4, whiteSpace: 'nowrap' }

                        })
                    // React.createElement(
                    //     "button",
                    //     {
                    //         onClick: () => { if (!isLoading) void onSearchClick(); },
                    //         disabled: isLoading,
                    //         style: { backgroundColor: '#0078d4', color: 'white', border: 'none', padding: '12px', borderRadius: 4, whiteSpace: 'nowrap' }
                    //     },
                    //     "Find"
                    // )
                ),
                // Messages
                message && React.createElement("div", { style: { color: "red", marginTop: 10, marginBottom: 10, backgroundColor: 'white', padding: 8, borderRadius: 4 } }, message),
                isLoading && React.createElement("div", { style: { color: "blue", marginTop: 10, marginBottom: 10, backgroundColor: 'white', padding: 8, borderRadius: 4 } }, "Loading..."),
                // Inspection Cards
                React.createElement(
                    "div",
                    { style: { display: "flex", flexDirection: "column" as const, gap: 12 } },
                    // Pending Card
                    React.createElement(
                        "div",
                        {
                            onClick: openScheduled,
                            style: {
                                ...STYLES.border,
                                ...STYLES.rounded4,
                                ...STYLES.dFlex,
                                ...STYLES.alignItemsCenter,
                                ...STYLES.justifyContentBetween,
                                ...STYLES.p3,
                                ...STYLES.gap3,
                                cursor: isActionDisabled ? 'not-allowed' : 'pointer',
                                opacity: isActionDisabled ? 0.5 : 1,
                                pointerEvents: isActionDisabled ? 'none' : 'auto'
                            }
                        },
                        React.createElement(
                            "div",
                            { style: { ...STYLES.flexGrow1, ...STYLES.dFlex, ...STYLES.alignItemsCenter, ...STYLES.gap3 } },
                            React.createElement("div", { style: { ...STYLES.icon, ...STYLES.rounded3, ...STYLES.bgBrownLight } }
                                , React.createElement("img", {
                                    src: clockDataUri,
                                })
                            ),
                            React.createElement("h6", { style: STYLES.h6 }, "Remaining inspections today")
                        ),
                        React.createElement("div", { style: { ...STYLES.textBrown, ...STYLES.h1 } }, pendingIns ?? 0)
                    ),
                    // Completed Card
                    React.createElement(
                        "div",
                        {
                            onClick: closedWorkorders,
                            style: {
                                ...STYLES.border,
                                ...STYLES.rounded4,
                                ...STYLES.dFlex,
                                ...STYLES.alignItemsCenter,
                                ...STYLES.justifyContentBetween,
                                ...STYLES.p3,
                                ...STYLES.gap3,
                                cursor: 'pointer'
                            }
                        },
                        React.createElement(
                            "div",
                            { style: { ...STYLES.flexGrow1, ...STYLES.dFlex, ...STYLES.alignItemsCenter, ...STYLES.gap3 } },
                            React.createElement(
                                "div",
                                {
                                    style: {
                                        ...STYLES.icon,
                                        ...STYLES.rounded3,
                                        ...STYLES.bgBrownLight
                                    }
                                },
                                React.createElement("img", {
                                    src: checkDataUri,     
                                })
                            ),
                            React.createElement("h6", { style: STYLES.h6 }, "Completed inspections for today")
                        ),
                        React.createElement("div", { style: { ...STYLES.textGreen, ...STYLES.h1 } }, completedIns ?? 0)
                    )
                )
            ),
            // Action Buttons
            React.createElement(
                "div",
                { style: STYLES.actions },
                React.createElement(
                    "button",
                    {
                        onClick: openScheduled,
                        disabled: isActionDisabled,
                        style: getButtonStyle({ ...STYLES.btnBlueDark, ...STYLES.textWhite, ...STYLES.rounded4, ...STYLES.p3, ...STYLES.dFlex, ...STYLES.alignItemsCenter, ...STYLES.justifyContentCenter, ...STYLES.gap3 })
                    },
                    React.createElement("img", {
                        src: calenderDataUri,
                    }),
                    React.createElement("span", null, "Scheduled Inspections")
                ),
                React.createElement(
                    "button",
                    {
                        onClick: startInspection,
                        disabled: isActionDisabled,
                        style: getButtonStyle({
                            ...STYLES.btnRedDark,
                            ...STYLES.textWhite,
                            ...STYLES.rounded4,
                            ...STYLES.p3,
                            ...STYLES.dFlex,
                            ...STYLES.alignItemsCenter,
                            ...STYLES.justifyContentCenter,
                            ...STYLES.gap3
                        })
                    },
                    [
                        React.createElement("img", {
                            src: startDataUri,
                        }),
                        React.createElement("span", { key: "text" }, "Start Inspection")
                    ]
                )
            )
        ),
        // Search Results Modal
        showResults && React.createElement(SearchResults, {
            results: searchResults,
            onRecordClick: onRecordClick,
            onClose: onCloseResults
        })
    );
};