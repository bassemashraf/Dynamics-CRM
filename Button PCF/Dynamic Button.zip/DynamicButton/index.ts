/* eslint-disable */

import * as React from "react";
import * as ReactDOM from "react-dom";
import { PrimaryButton, IconButton } from "@fluentui/react/lib/Button";
import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class DynamicButton implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private _context: ComponentFramework.Context<IInputs>;
    private _container: HTMLDivElement;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this._context = context;
        this._container = container;

        // Render the React component
        this.renderButton();
    }

    private getJavaScriptCode(): string | null {
        const field = this._context.parameters.jsCodeField;
        if (field && field.raw) {
            return field.raw as string;
        }
        return null;
    }

    private getButtonTextEnglish(): string {
        const field = this._context.parameters.buttonText;
        if (field && field.raw) {
            return field.raw as string;
        }
        return "";
    }

    private getButtonTextArabic(): string {
        const field = this._context.parameters.buttonTextArabic;
        if (field && field.raw) {
            return field.raw as string;
        }
        return "";
    }

    private getButtonText(): string {
        const languageId = this.getLanguageId();
        const arabicLanguageId = 1025; 
        

        const isArabic = languageId === arabicLanguageId || 
                        languageId === 1026 || 
                        languageId === 2049 || 
                        languageId === 3073 ||
                        languageId === 4097 || 
                        languageId === 5121;  
        
        const arabicText = this.getButtonTextArabic();
        const englishText = this.getButtonTextEnglish();
        
        // Return Arabic text if language is Arabic and Arabic text is available
        if (isArabic && arabicText && arabicText.trim() !== "") {
            return arabicText;
        }
        
        // Otherwise return English text (or Arabic as fallback if English is empty)
        return englishText || arabicText || "";
    }

    private getButtonColor(): string {
        const field = this._context.parameters.buttonColor;
        if (field && field.raw) {
            return field.raw as string;
        }
        return "#307eafff"; // Default color
    }

    private getButtonIcon(): string | null {
        const field = this._context.parameters.buttonIcon;
        if (field && field.raw) {
            return field.raw as string;
        }
        return null;
    }

    private getLanguageId(): number {
        return this._context.userSettings.languageId;
    }

    private getRelatedRecordId(): string {
        const pageContext = (this._context as any).page;
        if (pageContext && pageContext.entityId) {
            return pageContext.entityId;
        }
        return "00000000-0000-0000-0000-000000000000";
    }

    private async handleButtonClick(): Promise<void> {
        const jsCode = this.getJavaScriptCode();

        if (!jsCode || jsCode.trim() === "") {
            console.error("No JavaScript code found in the field");
            this._context.navigation.openAlertDialog({
                text: "No JavaScript code configured for this button.",
                confirmButtonLabel: "OK"
            });
            return;
        }

        try {
            const languageId = this.getLanguageId();
            const relatedRecord = this.getRelatedRecordId();
            console.log("Executing JavaScript with parameters:", {
                languageId,
                relatedRecord
            });

            Xrm.Utility.showProgressIndicator("");

            await new Promise(resolve => setTimeout(resolve, 20));

            const runCode = new Function(
                "pcfContext",
                "languageId",
                "relatedRecord",
                `"use strict"; return (async () => { ${jsCode} })();`
            );

            await runCode(this._context, languageId, relatedRecord);

        } catch (error: any) {
            console.error("Error executing JavaScript code:", error);
            this._context.navigation.openAlertDialog({
                text: `Error executing code: ${error.message || error}`,
                confirmButtonLabel: "OK"
            });
        } finally {
            Xrm.Utility.closeProgressIndicator();
        }
    }

    private renderButton(): void {
        const jsCode = this.getJavaScriptCode();
        const buttonText = this.getButtonText();
        const buttonColor = this.getButtonColor();
        const buttonIcon = this.getButtonIcon();
        const isDisabled = !jsCode || jsCode.trim() === "";

        // If no text provided, use IconButton instead
        if (!buttonText || buttonText.trim() === "") {
            const iconName = buttonIcon || "ButtonControl"; // Default icon if none provided

            ReactDOM.render(
                React.createElement(
                    IconButton,
                    {
                        className: "Jsaction",
                        iconProps: { iconName: iconName },
                        onClick: () => void this.handleButtonClick(),
                        title: iconName,
                        ariaLabel: iconName,
                        disabled: isDisabled,
                        style: {
                            width: "40px",
                            height: "40px"
                        }
                    }
                ),
                this._container
            );
        } else {
            // Use PrimaryButton with text
            const iconProps = buttonIcon ? { iconName: buttonIcon } : undefined;

            ReactDOM.render(
                React.createElement(
                    PrimaryButton,
                    {
                        className: "Jsaction",
                        text: buttonText,
                        iconProps: iconProps,
                        onClick: () => void this.handleButtonClick(),
                        disabled: isDisabled,
                        style: {
                            backgroundColor: buttonColor,
                            border: `1px solid ${buttonColor}`,
                            borderColor: buttonColor
                        }
                    }
                ),
                this._container
            );
        }
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this._context = context;
        this.renderButton();
    }

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {
        ReactDOM.unmountComponentAtNode(this._container);
    }
}